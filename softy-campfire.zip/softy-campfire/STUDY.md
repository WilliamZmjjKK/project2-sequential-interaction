# Softy Campfire

A single-screen, phone-first touch study in two steps, set in soft snowdrifts under a pale winter sky with snow falling. A campfire is buried in the near drifts; a faint warm glow shows through the snow. **Step 1:** the user swipes fast across the screen, and the "wind" of each stroke blows the loose snow off the fire. When 92% is cleared, the fire ignites with a whoomph and a chord, and the scene sinks into blue hour. **Step 2:** the user taps falling snowflakes to play glassy tones, and rubs the fire to build heat; when the heat peaks, the fire flares, sends up a plume of smoke and plays a short melody.

Source: exported from claude.ai artifact `1Lwf42rEf82kJdgFT24i1s` (version `1791336288-d1c7`). `index.html` is a byte-identical copy of the published page (sha256 `b73e66fb…13b225e`); line numbers below refer to it.

## Running it

- No build step, no dependencies, no asset files. All styles, drift curves, sprites, the campfire drawing and sound synthesis are inline in `index.html`.
- Open `index.html` directly in a browser, or serve the folder: `npm start` (runs `npx http-server`), or `python3 -m http.server`.
- Best viewed on a phone or in browser dev-tools device mode. On screens ≥ 560px wide the stage is shown as a 430×900 phone-shaped card centred on the page.
- Requires: Canvas 2D (incl. `multiply`/`lighter` compositing), Pointer Events, Web Audio API (`AudioContext` / `webkitAudioContext`), `ResizeObserver` (falls back to `resize`). Audio starts on the first touch (autoplay rules). `navigator.vibrate` used if present.
- Optional phone-shake input exists but is **switched off**: `const SHAKE = false` (L116), because device motion can't be used inside the artifact viewer. Set it to `true` when hosting the file yourself; on iOS this reveals an "Enable shake" button that requests motion permission (served over HTTPS).
- Note: the platform wrapper put `<title>` inside `<body>` (line 2); browsers accept this. It was left untouched to keep the export identical.
- `softy-1-drift.svg` is mentioned in comments as the design source; its curves and colours are copied into `HILLS` (L123–130). The file is not loaded and not required.

## Main visual and interactive components

| Component | What it is | Where |
|---|---|---|
| Stage | Full-bleed container (phone-card on wide screens), `touch-action: none` | HTML L99; CSS `#stage` L27–46 |
| Canvas `#cv` | All drawing | HTML L100; `frame()` L560–732 |
| Static backdrop | Sky gradient, soft sun, three far drifts, the floor drift, and the cold campfire (melted patch, stone ring, three logs), pre-rendered to an offscreen canvas | `buildBg()` L213–263 |
| Snow cover | Three near drifts made of 46 columns; each column's erosion `e[i]` (0–1) lowers it from its starting height `b0` to a low bank `b1`; drawn with three offset passes for a soft crest | data `COVER` L133, `layout()` L279–282, `coverLayer()` L535–551 |
| Buried-fire glow | Faint warm multiply glow through the snow, stronger as progress rises; small embers show where snow is scooped | L588–604 |
| Dusk + firelight | Scene darkens to blue hour once lit (`dusk`); additive orange light pool scaled by heat/boost | L605–616 |
| Flames, sparks, smoke | Particle systems using radial-gradient sprites (`SPR`, L188–191) | flames L619–639, sparks L640–647, smoke L649–665 |
| Falling snow | 84 flakes with shadows; in step 2 they fall slower and sway on a wave; tapped flakes "pop" | `newFlake()` L265, drawn L679–692 |
| Blown snow | Puffs thrown up off the drift while eroding | `puff()` L391, drawn L667–677 |
| Rings | Expanding rings: white on a tapped flake, warm on ignition/flare | pushed in `succeed`/`flare`/`tapFlake`; drawn L695–703 |
| Ghost-finger hint | When idle in step 1, a translucent finger repeatedly makes three quick zig-zag strokes down into the drift | `GHOST`/`ghostAt()` L553–558, drawn L705–721 |
| Caption pill `.cap` | Two step dots + instruction text (with live % in step 1) | HTML L101–104; CSS L49–79; `caption()` L362–369 |
| Replay button `#replay` | Top-right "Start over", hidden until step 2 | HTML L106–108; handler L506 |
| Shake button `#shakeBtn` | Top-left, iOS only, only when `SHAKE` is true | HTML L105; L508–532 |
| Sound engine | Master + compressor, feedback delay; looping noise feeding a band-passed **wind** bed and a low-passed **fire** bed; `glass` (sine bell) and `warm` (filtered triangle) voices; `crackle()` and `whoomph()` noise bursts | L288–359 |

## States, user actions, feedback and transitions

State variable `state` (L168): `'snow' → 'clear' → 'fire'`, with `reset()` back to `'snow'`.

1. **snow** — drifts cover the fire. Caption "Swipe fast to clear the snow" (+ " · NN%"). Dot 1 active. After 0.9 s idle the ghost finger demonstrates the gesture.
   - *Pointer down* (L473): starts audio, stops the hint.
   - *Pointer move* (L482–497): every stroke is wind — it pushes nearby flakes, blown snow and smoke (`wind()` L399); wind noise volume and brightness follow speed. Only **fast** strokes erode: `erode()` (L414) removes snow from columns under/near the finger, scaled by speed above a threshold (~320 px/s × scale), throwing up puffs. Slow drags just stir the flakes.
   - `measure()` (L408) averages on-screen erosion into `progress`, updates the caption %, and calls `succeed()` at `CFG.CLEAR_AT` (0.92).
   - *Shake* (if enabled): `shake()` (L430) gusts all particles and erodes every column a little.
2. **clear** (1.5 s, L566–569) — `succeed()` (L370): whoomph, warm F-major chord + two glass notes, vibration, a large warm ring, 26 sparks, a puff from every remaining column; the rest of the snow melts away automatically. Fire fades in (`lit`), sky darkens (`dusk`). Dot 1 → ember, dot 2 active, caption "Tap a snowflake · rub the fire", replay shown.
3. **fire** — flames burn with a low crackling bed; flakes fall at half speed and sway.
   - *Tap a flake* (outside the fire, L479): nearest flake within ~48 px (`pickFlake()` L465) plays a glass tone — higher near the top of the screen, a step lower for big flakes (`tapFlake()` L458) — pops and shows a white ring.
   - *Rub the fire* (move inside `inFire()` radius, L444, L491–496): `heat` rises with distance rubbed; sparks and crackles increase; fire grows. Heat decays when rubbing stops (L575).
   - *Heat reaches 1* → `flare()` (L448): fire boosts, smoke plume (`smokeBurst`), cycles through 3 melodies (`MELODIES` L137–141), 24 sparks, warm ring, vibration; 1.9 s cooldown before the next flare.
   - After 4 taps/flares combined the caption fades (`acts`, `.quiet`).
   - Wind from any stroke still pushes snow and smoke around.
   - *Replay* → `reset()` (L382): snow cover restored, particles cleared, dots/caption reset.

## Tuning knobs

- `CFG.FIRE_Y` (0.80) — campfire position as a fraction of screen height.
- `CFG.CLEAR_AT` (0.92) — share of snow that must be blown off.
- `SHAKE` (false) — enable phone-shake input.
- `COVER` b0/b1 — start/end heights of the three near drifts; `SCALE` (F major pentatonic F4–F6) and `MELODIES`.
- Erosion speed threshold and rate: `erode()` L415, L423. Rub sensitivity: L492. Flare cooldown: L450.

## Notes for connecting to other studies

- All code is one IIFE (L112–739) with no exports; to sequence it, wrap it in an `init(stageEl)` / `destroy()` pair or load it in an iframe.
- Natural hand-off points: `succeed()` (end of step 1) and `flare()` / the fourth action (`acts >= 4`, end of step 2).
- The `requestAnimationFrame` loop and `AudioContext` are never torn down; a host should cancel the loop and `AC.close()` when leaving.
- Shares structure with the other studies in this set: same stage/phone-card layout, `.cap` pill with two step dots, `#replay` chip, `audio()` unlock-on-touch pattern, `caption()` / `succeed()` / `reset()` naming, and `prefers-reduced-motion` damping via `calm`. Palette here: sky `#b9c7de`, page `#131829`, ember `#ffb46a`, white ink.
