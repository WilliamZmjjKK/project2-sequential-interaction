# Glossy Spot UV

A single-screen, phone-first touch study in two steps, modelled on spot-UV printing: wavy stripes of clear coat on matte black card stock. At first the stripes are dull, barely visible and slowly "breathing" in a drifting pool of light. **Step 1:** the user drags along the waves; wherever the finger passes, the coat is polished and becomes a mirror-like gloss that reflects moving softbox highlights. Once 62% of the wave surface is polished, a chime plays and the gloss floods out from the last touch over every wave. **Step 2:** the waves float gently; stroking across them makes each wave ripple and glow and plays notes, so a stroke becomes a short melody.

Source: exported from claude.ai artifact `3vD3UyhANxnShTRKVBPRZj` (version `1791676468-4814`). `index.html` is a byte-identical copy of the published page (sha256 `9c6baeae…80ed935e`); line numbers below refer to it.

## Running it

- No build step, no dependencies, no asset files. Styles, wave geometry, paper grain, gloss gradients and sound synthesis are all inline in `index.html`.
- Open `index.html` directly in a browser, or serve the folder: `npm start` (runs `npx http-server`), or `python3 -m http.server`.
- Best viewed on a phone or in browser dev-tools device mode. On screens ≥ 560px wide the stage is shown as a 430×900 phone-shaped card centred on the page.
- Requires: Canvas 2D (incl. `Path2D`, `getImageData`, `destination-in`/`screen` compositing), Pointer Events, Web Audio API (`AudioContext` / `webkitAudioContext`), `ResizeObserver` (falls back to `resize`). Audio starts on the first touch (autoplay rules). `navigator.vibrate` used if present.
- Note: the platform wrapper put `<title>` inside `<body>` (line 2); browsers accept this. It was left untouched to keep the export identical.
- `glossy-9-spot-uv.svg` is mentioned in a comment as the design source; it is not loaded and not required.

## Main visual and interactive components

| Component | What it is | Where |
|---|---|---|
| Stage | Full-bleed container (phone-card on wide screens), `touch-action: none` | HTML L97; CSS `#stage` L27–46 |
| Canvas `#cv` | All drawing | HTML L98; `frame()` L410–534 |
| Matte stock + grain | Flat `#1d1e21` fill plus a pre-rendered random-noise paper grain | grain built in `layout()` L172–176; drawn L436–441 |
| Wave bands | Horizontal wavy stripes (46 px pitch × scale), each a closed path; shape animates slowly, floats in step 2, and ripples where excited | `topY()` L150–158, `thick()` L159, `buildBands()` L384–395 |
| Dull coat | Bands filled with a faint grey radial "breathing" light that drifts around the screen | L443–448 |
| Polish mask | Low-res offscreen canvas (4 px cells); each drag stamps a soft radial brush into it | `brush` L185–190, `polish()` L191–199, mask created in `layout()` L177–182 |
| Gloss layer | Bands filled with a diagonal multi-stop "softbox" gradient (`sheen()`, L401–408) that shifts with finger x and time, then cut by the mask (`destination-in`) so only polished areas show | L450–464 |
| Fingertip reflection | Elongated white glint trail following the finger, rotated to the stroke direction, clipped to the bands, fading ~0.4 s after lifting | trail built in pointermove L362–364; drawn L481–502 |
| Wave glow (step 2) | Stroked bands glow (screen blend) around the touch point while they ring | `ex[]`/`exX[]` excitation; drawn L466–479 |
| Step-1 hint | On touch (or 1.8 s after lifting), the nearest band is outlined and dots flow along it in both directions from the finger, plus a finger ring | L504–525 |
| Caption pill `.cap` | Two step dots + instruction text (with live % in step 1) | HTML L99–102; CSS L48–79; `caption()` L286–293 |
| Replay button `#replay` | Top-right "Start over", hidden until step 2 | HTML L103–105; CSS L80–93; handler L381 |
| Sound engine | Master + compressor, feedback delay; looping noise → band-pass **rub** hiss; three-sine low **hum**; `glass` bell voice and `low` thud voice | L223–283 |

## States, user actions, feedback and transitions

State variable `state` (L143): `'dull' → 'wipe' → 'play'`, with `reset()` back to `'dull'`.

1. **dull** — caption "Touch the surface". Dot 1 active.
   - *Pointer down* (L311–329): starts audio; if on a band, polishes a spot. Caption → "Drag along the waves".
   - *Drag* (L338–366): `polish()` stamps along the path, revealing gloss. The fingertip glint follows the stroke direction (`hlAng`). Crossing into a different band plays a **low** note if that spot is still dull, or a quiet high **glass** note if already polished. Friction sound: dark hum + low hiss on dull coat, bright hiss on polished coat, volume follows speed (L527–533).
   - The hint (band outline + flowing dots) shows until the finger has travelled ~140 px, and again for 1.8 s after release (`hintHold`, L370).
   - Every 8 frames `measure()` (L208–217) samples the mask over band area → `progress`; caption shows % of target. At `CFG.LIT_AT` (0.62) → `succeed()`.
2. **wipe** (1.3 s, L415) — `succeed()` (L294–301): ascending 4-note glass chime + low C, vibration; the mask floods out radially from the last touch until everything is glossy (L423–430). Dot 1 → glowing coat colour, dot 2 active, replay shown.
3. **play** — caption "Stroke the waves"; bands gently float (`floatAmt`).
   - *Pointer down on a band*: band excited (ripple + glow), one note (`strokeNote()` L330–337; higher up the screen = higher pitch, C major pentatonic C5–G6, avoids repeating the same note).
   - *Stroke*: each new band crossed (or every ~70 px of travel, ≥85 ms apart) plays a note, louder with speed; bands ripple where touched.
   - *Release* (L371–375): after ≥2 notes a resolving home tone closes the phrase.
   - After 5 notes the caption fades (`acts`, `.quiet`).
   - *Replay* → `reset()` (L302–307): mask cleared, all dull again.

## Tuning knobs

- `CFG.LIT_AT` (0.62) — share of wave surface to polish before step 2.
- `CFG.BRUSH` (58) — polish radius in px (soft falloff).
- `SCALE` (C major pentatonic) and `LOW` (low C–C register for dull bands).
- Band pitch 46 px and thickness in `topY()`/`thick()`; mask resolution `MS` (L138); gloss colours in `sheen()` stops.

## Notes for connecting to other studies

- All code is one IIFE (L109–541) with no exports; to sequence it, wrap it in an `init(stageEl)` / `destroy()` pair or load it in an iframe.
- Natural hand-off points: `succeed()` (end of step 1) and the fifth note in **play** (`acts >= 5`, end of step 2).
- The `requestAnimationFrame` loop and `AudioContext` are never torn down (the hum oscillators run continuously at zero gain); a host should cancel the loop and `AC.close()` when leaving.
- Resizing keeps polish progress: `layout()` rescales the old mask into the new one (L178–182).
- Shares structure with the other studies in this set: same stage/phone-card layout, `.cap` pill with two step dots, `#replay` chip, `audio()` unlock-on-touch pattern, `caption()` / `succeed()` / `reset()` naming, and `prefers-reduced-motion` damping via `calm`. Palette here: page `#0c0d0f`, stock `#1d1e21`, ink `#f4f6f9`, coat `#cfd3da`.
